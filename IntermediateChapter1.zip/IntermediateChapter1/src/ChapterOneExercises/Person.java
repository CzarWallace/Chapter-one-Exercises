package ChapterOneExercises;

public class Person {

    private String fullName;
    private int age;
    private String eyeColor;

    // no argument constructor
    public  Person(){
        fullName = "Anthony Wallace";
        age      =   40;
        eyeColor =    "Brown";
        System.out.printf("Full name = %s, age = %d, eyes color = %s", fullName, age, eyeColor);

        }
    // Constructor with 3 argument
    public Person(String fN, int age, String eC){
        this.fullName = fN;
        this.age = age;
        this.eyeColor = eC;

    }

    // Getter and setter
    public String getFullName(){
        return fullName;
    }
      public void setFullName(String fullName){
       this. fullName = fullName;
      }
      public int getAge(){
        return age;
      }
      public void setAge(int age){
        this.age = age;
      }
      public String getEyeColor(){
        return eyeColor;
      }
      public void setEyeColor(String eyeColor){
        this.eyeColor = eyeColor;
      }
    public void talk(){
        System.out.print(" Welcome, coder! I'm " + fullName );
    }


    public String toString(){

       return  ("I'm:  " + fullName + ", Age: " + age + ", Eyes color:" + eyeColor);
      }


    }



