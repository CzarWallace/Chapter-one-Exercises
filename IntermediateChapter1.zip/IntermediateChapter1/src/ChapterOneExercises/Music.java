package ChapterOneExercises;
//my instance variable
public class Music {
    private String songTitle;
    private  int yearReleased;
    private double minutesOfLength;
// no argument constructon
    public Music(){
        songTitle = "World greatest";
        yearReleased = 2018;
        minutesOfLength = 4.39;

    }
// with 3 argument constructor
    public Music(String songTitle, int yearReleased, double minutesOfLength) {
        this.songTitle = songTitle;
        this.yearReleased = yearReleased;
        this.minutesOfLength = minutesOfLength;
    }
//getter and setter
    public String getSongTitle() {
        return songTitle;
    }

    public int getYearReleased() {
        return yearReleased;
    }

    public double getMinutesOfLength() {
        return minutesOfLength;
    }

    public void setSongTitle(String songTitle) {
        this.songTitle = songTitle;
    }

    public void setYearReleased(int yearReleased) {
        this.yearReleased = yearReleased;
    }

    public void setMinutesOfLength(double minutesOfLength) {
        this.minutesOfLength = minutesOfLength;
    }
    // instance method
    public void lyric(){
        System.out.println(" Lyrics of the song.");


    }
//toString method
    @Override
    public String toString() {
        return "Music{" +
                "songTitle='" + songTitle + '\'' +
                ", yearReleased=" + yearReleased +
                ", minutesOfLength=" + minutesOfLength +
                '}';
    }
}
