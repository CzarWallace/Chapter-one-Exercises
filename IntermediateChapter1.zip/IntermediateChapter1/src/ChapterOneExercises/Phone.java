package ChapterOneExercises;

public class Phone {
    // Attribute
    private int rearFacingCameraLense;
    private  String brandName;
    private int version;
    private  String phoneType;
//no argument constructor
    public Phone(){
        rearFacingCameraLense = 2;
        brandName = "Samsumg Galaxy";
        version = 11;
        System.out.println("Rear facing Camera lense: " + rearFacingCameraLense);
        System.out.println("Brand is: " + brandName );
        System.out.println("Phone version: " + version );




    }
    // With argument constructor

    public Phone(int rearFacingCameraLense, String brandName, int version, String phoneType) {
        this.rearFacingCameraLense = rearFacingCameraLense;
        this.brandName = brandName;
        this.version = version;
        this.phoneType = phoneType;
    }
 // getter and setter
    public int getRearFacingCameraLense() {
        return rearFacingCameraLense;
    }

    public void setRearFacingCameraLense(int rearFacingCameraLense) {
        this.rearFacingCameraLense = rearFacingCameraLense;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }
//toString method
    @Override
    public String toString() {
        return "Phone: " +"["+
                " Rear Facing Camera Lense = " + rearFacingCameraLense +
                ", Brand Name = " + brandName +
                ", Version = " + version +
                ", Phone type = " + phoneType + "]";
    }

}
