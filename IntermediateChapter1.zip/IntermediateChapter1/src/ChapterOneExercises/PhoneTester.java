package ChapterOneExercises;

import java.util.ArrayList;

public class PhoneTester {
    public static void main(String[] args) {
     // no argument
        Phone phone1 = new Phone();
// With argument
        Phone phone2 = new Phone(3,"iPhone", 14,"Pro Max");
        Phone phone3 = new Phone(2,"motorola", 7,"Motorola edge");

        //ArrayList

        ArrayList phoneList = new ArrayList();
        phoneList.add(phone1);
        phoneList.add(phone2);
        phoneList.add(phone3);

        System.out.println(phoneList);
// Rear facing camera lense
        int lense = phone1.getRearFacingCameraLense() + phone2.getRearFacingCameraLense() + phone3.getRearFacingCameraLense();
        System.out.println("Rear facing camera lense = " + lense);





    }
}
