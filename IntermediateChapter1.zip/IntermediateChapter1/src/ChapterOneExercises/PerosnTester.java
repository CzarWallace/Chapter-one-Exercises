package ChapterOneExercises;

public class PerosnTester {
    public static void main(String args []){
        Person p1 = new Person();
        System.out.println();

        Person p2 = new Person();
        p2.getFullName();
        p2.setFullName("John Brown");
        System.out.println();
        p2.talk();

    }
}
