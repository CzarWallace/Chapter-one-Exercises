package ChapterOneExercises;

public class Cookbook {
    // my variable declaration
    private String cookbookName;
    private double numberOfIngredients;
    private String listOfIngredients;
    private String countryOfOrigin;

    //4 parameter constructor
    public Cookbook(String cookbookName, double numberOfIngredients, String listOfIngredients, String countryOfOrigin) {
        this.cookbookName = cookbookName;
        this.numberOfIngredients = numberOfIngredients;
        this.listOfIngredients = listOfIngredients;
        this.countryOfOrigin = countryOfOrigin;
    }

    // getter and setter
    public String getCookbookName() {
        return cookbookName;
    }

    public void setCookbookName(String cookbookName) {
        this.cookbookName = cookbookName;
    }

    public double getNumberOfIngredients() {
        return numberOfIngredients;
    }

    public void setNumberOfIngredients(double numberOfIngredients) {
        this.numberOfIngredients = numberOfIngredients;
    }

    public String getListOfIngredients() {
        return listOfIngredients;
    }

    public void setListOfIngredients(String listOfIngredients) {
        this.listOfIngredients = listOfIngredients;
    }

    public String getCountryOfOrigin() {
        return countryOfOrigin;
    }

    public void setCountryOfOrigin(String countryOfOrigin) {
        this.countryOfOrigin = countryOfOrigin;
    }
       // instance method
    public String isAfricanDish() {
        if (numberOfIngredients >= 10) {
            return ("It is a African Cookbook");
        }
        else{
            return ("It is an American or European Cookbook");
    }
    }


/// toString method
    @Override
    public String toString() {
        return "Cookbook{" +
                "cookbook Name = " + cookbookName +
                ", number Of Ingredients = " + numberOfIngredients +
                ", list Of Ingredients = " + listOfIngredients  +
                ", country Of Origin = " + countryOfOrigin  + " dish" +  "It is a " + isAfricanDish() +
                '}';
    }
}
