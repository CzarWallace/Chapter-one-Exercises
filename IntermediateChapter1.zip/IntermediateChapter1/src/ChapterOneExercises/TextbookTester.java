package ChapterOneExercises;

public class TextbookTester {
    public static void main(String args []){

        Textbook Tb1 = new Textbook("Hidden Wonders", "Ira E Aaron & Rena Koke",
                "1st", 352,1982);

        Textbook Tb2 = new Textbook("Management","Robbinss & Coulter", "14th", 715,2018);
        Textbook Tb3 = new Textbook("Guide to Networking Essentials", "Greg Tomsho", "8th", 819,2019);
        Textbook Tb4 = new Textbook("DataBase Concepts", "David M. Kroenke, David J Auer, Scott L. Vandenberg and Robert C Yoder",

                "9th", 536,2020);
        Textbook Tb5 = new Textbook("Introduction to Java", "Y. Daniel Liang", "12th", 1218,2019);


        System.out.println(Tb1);
        System.out.println();
        System.out.println(Tb2);
        System.out.println();
        System.out.println(Tb3);
        System.out.println();
        System.out.println(Tb4);
        System.out.println();
        System.out.println(Tb5);
        System.out.println();


        // I Try to use for loop to print my textbook, but it is not working

//             int i;
//        for( i = 1; i <= 5; i++){
//            System.out.printf("%s %s %s %s %s\n ", Tb1,Tb2,Tb3,Tb4,Tb5);
//
//
//        }



    }
}
