package ChapterOneExercises;

public class MusicTester {
    public static void main(String[] args) {

        Music song1 = new Music();
        System.out.println(song1.getSongTitle());

        song1.setSongTitle("“Do-Re-Mi”.");

        song1.lyric();




    }
}
