package ChapterOneExercises;

public class Textbook {
//my variable
    private String bookTitle;
    private String author;
    private String  edition;
    private  int numberOfPages;
    private  int yearPublish;
// no argument constructor
    public Textbook(){
       // int currentYear = 2022;


    }
// with 5 parameter constructor
    public Textbook(String BT, String auth, String Ed, int nP, int yp){
        this.bookTitle = BT;
        this.author = auth;
        this. edition = Ed;
        this. numberOfPages = nP;
        this.yearPublish = yp;
    }
//getter and setter
    public String getBookTitle(){
        return bookTitle;
    }
    public void setBookTitle(String bookTitle){
        this.bookTitle = bookTitle;

    }
    public String getAuthor(){
        return author;

    }
    public  void setAuthor(String author){
        this.author = author;
    }
    public String getEdition(){
        return edition;

    }
    public void setEdition(String edition){
        this.edition = edition;
    }
    public int getNumberOfPages(){
        return numberOfPages;
    }
    public void setNumberOfPages(int numberOfPages){
        this.numberOfPages = numberOfPages;
    }
    public int getYearPublish(){
        return yearPublish;
    }

    public void setYearPublish(int yearPublish){
        this.yearPublish = yearPublish;
    }

    //my instance boolean method
    public boolean isUpToDate(){

        if(2022 - yearPublish <= 4) {
            return true;
        }
        else return false;
    }
    // my toString

    public String toString(){
        return "[" + " Title: " + bookTitle + ", Author: " + author + ", Edition: " + edition +" edition"
                + ", Number of pages: " + numberOfPages + ", Year publish: " + yearPublish
                + " , Is it up to date: " + isUpToDate() + "]" ;
    }



}
