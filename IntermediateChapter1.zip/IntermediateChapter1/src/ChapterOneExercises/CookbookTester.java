package ChapterOneExercises;

public class CookbookTester {
    public static void main(String[] args) {

        Cookbook dish1 = new Cookbook("Rice and Stew", 5,"WhiteRice, chicken, fryingOil, tomatoes, onions","America" );
        Cookbook dish2 = new Cookbook("Fufu and soup", 11,"Cassava, goatmeat, fish, beef, chicken, okra, etc","African" );



        System.out.println(dish1);
        System.out.println(dish2);


    }
}
